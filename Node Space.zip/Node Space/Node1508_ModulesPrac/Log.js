// var log = {
//     info: function (info) {
//         console.log('Log the info , ' + info);
//     }
// }

//var logit = "Some log data to log";

var namesarray = [firstPerson={
    firstName: 'Beta',
    secondName: 'Prog'
},
secondPerson = {
    firstName: 'S',
    secondName: 'G'
}]

module.exports.logdata = namesarray;
