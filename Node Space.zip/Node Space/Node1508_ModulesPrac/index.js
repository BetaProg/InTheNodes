//Module prac 1508 v1 - index.js
var logModule = require('./Log.js');
//logModule.info('Hi There!');

console.log(logModule.logdata[0]['firstName']);