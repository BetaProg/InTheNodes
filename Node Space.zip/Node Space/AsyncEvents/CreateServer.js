var http = require('http');
var server = http.createServer(function (req, res){
    //handle incoming requests
    if(req.url == "/"){
        res.writeHead(200,{'Content-Type':'text/html'} );
        res.write('<html><h4>This is home page</h4></html>');
        res.end();
    }
    else if(req.url == "/student"){
        res.writeHead(200,{'Content-Type':'text/html'} );
        res.write('<html><h4>This is student page</h4></html>');
        res.end();
    }
    else{
        res.end('Invalid Reqeust');
    }
});
server.listen(5000);
console.log('Node is serving at this port - 5000..');