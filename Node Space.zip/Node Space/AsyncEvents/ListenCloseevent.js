var http = require('http');

var server = http.createServer(function(req, res){
    res.writeHead(200, {"Content-Type":"plain/text"});
    res.end("Response ended here");
});

server.on("close", function(){
    console.log("Connection closed here");
})

server.listen(9091);
server.close();