var http = require('http');

var instructionsNewVisitor = function(req, res){
    res.writeHead(200);
    res.end('This is in Callback part');
}
var server = http.createServer(instructionsNewVisitor);
server.listen(9090);